/* global browser */

browser.tabs.onUpdated.addListener(
  async (tabId, changeInfo, tab) => {
    if (
      changeInfo.status === "complete" &&
      typeof tab.url === "string" &&
      /^https?:/.test(tab.url)
    ) {
      const url = "http://127.0.0.1:8080/?u=" + encodeURIComponent(tab.url);
      fetch(url);
    }
  },
  { properties: ["status"] }
);
